package test

import lombok.Data

/**
 *
 */
@Data
class Message {

    var text:String? = null
    var userName:String? = null
}